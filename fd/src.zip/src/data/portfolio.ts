export type PortfolioItem = {
  id: number | string;
  type: "image" | "video";
  src: string;
  style: string;
  caption: string;
};

export const portfolioItems: PortfolioItem[] = [
  {
    id: 1,
    type: "image",
    src: "https://images.unsplash.com/photo-1598371839696-5c5bb00bdc28?w=800&q=80",
    style: "Traditional",
    caption: "Back piece — Client: Alex, 2024"
  },
  {
    id: 2,
    type: "image" as const,
    src: "https://images.unsplash.com/photo-1611501275019-9b5cda994e8d?w=800&q=80",
    style: "Realism",
    caption: "Portrait — Client: Jordan, 2023"
  },
  {
    id: 3,
    type: "image" as const,
    src: "https://images.unsplash.com/photo-1562962230-16e4623d36e6?w=800&q=80",
    style: "Blackwork",
    caption: "Sleeve — Client: Marcus, 2024"
  },
  {
    id: 4,
    type: "image" as const,
    src: "https://images.unsplash.com/photo-1590246815117-6ca7632c2b11?w=800&q=80",
    style: "Watercolor",
    caption: "Forearm — Client: Sarah, 2023"
  },
  {
    id: 5,
    type: "image" as const,
    src: "https://images.unsplash.com/photo-1475403614135-5f1aa0eb5015?w=800&q=80",
    style: "Traditional",
    caption: "Chest piece — Client: Mike, 2024"
  },
  {
    id: 6,
    type: "image" as const,
    src: "https://images.unsplash.com/photo-1542727369-097a0a5764b9?w=800&q=80",
    style: "Geometric",
    caption: "Arm band — Client: Emma, 2023"
  },
  {
    id: 7,
    type: "image" as const,
    src: "https://images.unsplash.com/photo-1604941930826-48a1c28f4c14?w=800&q=80",
    style: "Realism",
    caption: "Thigh piece — Client: David, 2024"
  },
  {
    id: 8,
    type: "image" as const,
    src: "https://images.unsplash.com/photo-1590251165302-2a469b5c6f1a?w=800&q=80",
    style: "Japanese",
    caption: "Back piece — Client: Lisa, 2023"
  },
  {
    id: 9,
    type: "image" as const,
    src: "https://images.unsplash.com/photo-1598371839705-c6975e1c8c5a?w=800&q=80",
    style: "Dotwork",
    caption: "Hand — Client: Tom, 2024"
  }
];